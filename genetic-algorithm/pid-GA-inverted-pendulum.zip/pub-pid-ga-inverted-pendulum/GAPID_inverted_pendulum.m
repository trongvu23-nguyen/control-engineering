
clc;
clear all
rand('state',sum(100*clock));

%% optional setup
% Jmin=100;

%% Set up parameters
max_generation = 200; % Stop condition #1
% GA will stop (Condition #1)if run max_generation
max_stall_generation = 50; % Stop condition#2
epsilon = 0.0001; % Stop condition#2 - error
% (Condition #2) for 50 generations continuously
% if J(n-1)-Jn<epsilon continuously, GA stop and display results

N = 20; % population size 20~30
% N-large: fast convergence, not optimze results
% N-small: slow convergence, not good results due to more mutation
npar = 3; % number chromosome 
range = [0 0 0;...
         100 100 100];
dec = [2 2 2]; %decimal point position ~ 99.
sig = [4 4 4]; %number of significant digits in chromosome 00.00-99.99
Pc = 0.8; %Pc>Pm The higher the crossover ratio, the more similar the offspring chromosomes are to the parents.
Pm = 0.2;
elitism = 1; %preserve the best individuals in the evolutionary process

rho = 0.01; %weight of fitness function

%% initialization: first generation - random 
par = Init(N,npar,range);

Terminal = 0; %flag: =0 algorithm not finished | =1 finished
generation = 0; %generation count variable
stall_generation = 0; %generation count variable if fitness function no change 

%% Evaluate the fitness of the initial population based on the minimum fitness function
for pop_index = 1:N,
    Kp = par(pop_index,1);
    Ki = par(pop_index,2);
    Kd = par(pop_index,3);
    sim('inverted_pendulum');
    J = (e'*e) + rho*(u'*u); %fitness J % e-error. u-control input.
    % if decreasing rho, error -> 0 fast. If increase rho, response fast
    fitness(pop_index)=1/(J+eps); %fitness fuction   
    
    %% optional setup
    % ?length(e)>95
%     if (length(e)>95)&&(J<Jmin)         
%             Kp
%             Ki
%             Kd
%             Jmin=J
%             fitness(pop_index)=1/(J+eps); % find minimum                                     
%     else                                                                 
%             J=1000;                           
%             fitness(pop_index)=1/(J+eps);      
%     end 
end
[bestfit0,bestchrom] = max(fitness); %fitness large -> J small

%% loop - run until condition is satisfied
while~Terminal,
    generation = generation+1;
    
    disp(['generation #' num2str(generation) ' of maximum ' num2str(max_generation)]);
    %% Encode
    pop = Encode_Decimal(par,sig,dec);
    %% Selection
    parent = Select_Linear_Ranking(pop,fitness,0.5,elitism,bestchrom);
    %% Crossover
    child = Cross_Twopoint(parent,Pc,elitism,bestchrom);
    %% Mutation
    pop = Mutate_Uniform(child,Pm,elitism,bestchrom);
    %% Decode
    par = Decode_Decimal(pop,sig,dec);
    %% re-evaluate the fitness of the population after each generation of evolution
    for pop_index = 1:N
        Kp = par(pop_index,1);
        Ki = par(pop_index,2);
        Kd = par(pop_index,3);
        sim('inverted_pendulum');
        J = (e'*e) + rho*(u'*u);
        fitness(pop_index)=1/(J+eps);
        
        %% optional setup
%         if (length(e)>95)&&(J<Jmin)                                                                          %neu mo phong chay duoc du 10000 mau(100s) thi
%             Kp
%             Ki
%             Kd
%             Jmin=J
%             fitness(pop_index)=1/(J+eps);                                                             %den giay thu 95)
%         else                                                                                %neu mo phong chay chua den duoc giay thu 95 ma da dung
%             J=1000;                                                                        %nghia la gia tri da dao dong dem mat on dinh
%             fitness(pop_index)=1/(J+eps);
%         end
    end
	[bestfit(generation),bestchrom] = max(fitness);

%% Check stop condition
if generation == max_generation % stop conditon 1
    Terminal = 1; 
elseif generation > 1 
    if abs(bestfit(generation)-bestfit(generation-1)) < epsilon
        stall_generation = stall_generation +1;
        if stall_generation == max_stall_generation 
            Terminal = 1;
        end
    else
        stall_generation = 0;
    end
end

end %While

plot(1./bestfit)    % graphing the fitness 
%1.bestfit=J-fitness
Kp = par(bestchrom,1)  % display parameters after calibration
Ki = par(bestchrom,2)
Kd = par(bestchrom,3)   
J=1/bestfit(end) % Display the last fitness J
sim('inverted_pendulum'); % Simulate the results after calibration