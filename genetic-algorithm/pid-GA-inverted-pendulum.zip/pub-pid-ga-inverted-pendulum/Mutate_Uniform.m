% Programmed by   : LY VA VY 
% Last updated    : 26/4/2023
% MUTATION Mutation(Mutate_Uniform)
% Mutate_Uniform.m :chuong trinh con dot bien deu

function newpop=Mutate_Uniform(pop,Pm,elitism,bestchrom)

if (nargin < 4),
   error(['Too few input arguments.']);
end;

[N,L]=size(pop);

newpop=pop;
for pop_index= 1:N,
   if (elitism==0) || (elitism==1 && pop_index~=bestchrom),
      for gene_index = 1:L,
         if Pm > rand				% If true then mutate  
            rand_gene=rand*10;				% Creat a random gene
            
            % If it is the same as the one already there or rand_gene=10 then 
            % generate another random allele in the alphabe
            while (pop(pop_index,gene_index)==rand_gene-rem(rand_gene,1)||rand_gene==10),
               rand_gene=rand*10;
            end;
            
            newpop(pop_index,gene_index)=rand_gene-rem(rand_gene,1);
         end  
      end  
   end  
end  