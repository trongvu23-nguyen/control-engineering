% Programmed by: LY VA VY
% Last updated : 26/4/2023
% ENCODE Encode parameters to base-10chromosome strings(Encode_Decimal_Unsigne
% Encode_Decimal_Unsigne.m :chuong trinh con ma hoa thap phan

% Input: 	par		: parameters
%  			sig		: significant figures
%			dec		: decimal point
% Output:   chrom   : chromosomes

function pop=Encode_Decimal(par,sig,dec)

if (nargin < 3),
   error(['Too few input arguments. Use: pop=Encode_Decimal(par,sig,dec)']);
end;

if size(sig)~=size(dec),
   error(['Mismatch betweem SIG and DEC']);
end;

[N,d]=size(par);

% Initialize: the first parameter starts at the first digit (this is the sign digit)
% Determine the start point of the other parameters.
% It is the start of the last parameter plus
% the no. of sig. figs. plus one for sign

for pop_index = 1:N,				% population pointer
  	gene_index = 1;
    for par_index = 1:d,  			% parameter pointer                   
        
        if par(pop_index,par_index)<0,
            pop(pop_index,gene_index)=0;
        else
            pop(pop_index,gene_index)=9;
        end
        gene_index=gene_index+1;
        
        temp(par_index)=abs(par(pop_index,par_index))/10^dec(par_index);
        
		for count = 1:sig(par_index),
            temp(par_index)=temp(par_index)*10;
            pop(pop_index,gene_index)=temp(par_index)-rem(temp(par_index),1);
      	    temp(par_index)=temp(par_index)-pop(pop_index,gene_index);
            gene_index=gene_index+1;
        end         
   end % Ends "for par_index=..." loop
end    % Ends "for pop_index=..." loop