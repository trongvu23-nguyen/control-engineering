
clc;
clear all
rand('state',sum(100*clock));

%% initial state
theta_int=0;
theta_d_int=0;
p_int=0;
p_d_int=0;

%% optional setup
Jmin=100000;

%% Set up parameters
max_generation = 200; % Stop condition #1
% GA will stop (Condition #1)if run max_generation
max_stall_generation = 50; % Stop condition#2
epsilon = 0.0001; % Stop condition#2 - error
% (Condition #2) for 50 generations continuously
% if J(n-1)-Jn<epsilon continuously, GA stop and display results

N = 20; % population size 20~30
% N-large: fast convergence, not optimze results
% N-small: slow convergence, not good results due to more mutation
npar = 4; % number chromosome 
range = [0 0 0 0;...
         10 10 10 10];
dec = [1 1 1 1]; %decimal point position ~ 99.
sig = [3 3 3 3]; %number of significant digits in chromosome 00.00-99.99
Pc = 0.6; %Pc>Pm The higher the crossover ratio, the more similar the offspring chromosomes are to the parents.
Pm = 0.4;
elitism = 1; %preserve the best individuals in the evolutionary process

rho = 0.02; %weight of fitness function

%% initialization: first generation - random 
par = Init(N,npar,range);

Terminal = 0; %flag: =0 algorithm not finished | =1 finished
generation = 0; %generation count variable
stall_generation = 0; %generation count variable if fitness function no change 

%% Evaluate the fitness of the initial population based on the minimum fitness function
for pop_index = 1:N,
    Kp1 = par(pop_index,1)-5;
    Ki1 = 0;
    Kd1 = par(pop_index,2)-5;
    Kp2 = par(pop_index,3)-5;
    Ki2 = 0;
    Kd2 = par(pop_index,4)-5;
    sim('ball_n_beam_center_simulink');
    J = (e'*e) + (theta'*theta); %fitness J % e-error. u-control input.
    % if decreasing rho, error -> 0 fast. If increase rho, response fast
    %fitness(pop_index)=1/(J+eps); %fitness fuction   
    Jmin=J;
    %% optional setup
    if (length(e)>9500)&&(J<Jmin)         
            Kp1
            Ki1
            Kd1
            Kp2
            Ki2
            Kd2
            Jmin=J
            fitness(pop_index)=1/(J+eps); % fitness fuction %find minimum                                     
    else                                                                 
            J=10^100;                           
            fitness(pop_index)=1/(J+eps);      
    end 
end
[bestfit0,bestchrom] = max(fitness); %fitness large -> J small 
%???

%% loop - run until condition is satisfied
while~Terminal,
    generation = generation+1;
    
    disp(['generation #' num2str(generation) ' of maximum ' num2str(max_generation)]);
    %% Encode
    pop = Encode_Decimal(par,sig,dec);
    %% Selection
    parent = Select_Linear_Ranking(pop,fitness,0.5,elitism,bestchrom);
    %% Crossover
    child = Cross_Twopoint(parent,Pc,elitism,bestchrom);
    %% Mutation
    pop = Mutate_Uniform(child,Pm,elitism,bestchrom);
    %% Decode
    par = Decode_Decimal(pop,sig,dec);
    %% re-evaluate the fitness of the population after each generation of evolution
    for pop_index = 1:N
        Kp1 = par(pop_index,1)-5;
        Ki1 = 0;
        Kd1 = par(pop_index,2)-5;
        Kp2 = par(pop_index,3)-5;
        Ki2 = 0;
        Kd2 = par(pop_index,4)-5;
        sim('ball_n_beam_center_simulink');
        J = (e'*e) + (theta'*theta);
        %fitness(pop_index)=1/(J+eps);
        
        %% optional setup
        if (length(e)>9500)&&(J<Jmin)         
                Kp1
                Ki1
                Kd1
                Kp2
                Ki2
                Kd2
                Jmin=J
                fitness(pop_index)=1/(J+eps); % find minimum                                     
        else                                                                 
                J=10^100;                         
                fitness(pop_index)=1/(J+eps);      
        end 
    end
	[bestfit(generation),bestchrom] = max(fitness);

%% Check stop condition
if generation == max_generation % stop conditon 1
    Terminal = 1; 
elseif generation > 1 
    if abs(bestfit(generation)-bestfit(generation-1)) < epsilon
        stall_generation = stall_generation +1;
        if stall_generation == max_stall_generation 
            Terminal = 1;
        end
    else
        stall_generation = 0;
    end
end

end %While

plot(1./bestfit)    % graphing the fitness 
%1.bestfit=J-fitness
Kp1 = par(bestchrom,1)-5  % display parameters after calibration
Ki1 = 0
Kd1 = par(bestchrom,2)-5
Kp2 = par(bestchrom,3)-5
Ki2 = 0
Kd2 = par(bestchrom,4)-5
J=1/bestfit(end) % Display the last fitness J
sim('ball_n_beam_center_simulink'); % Simulate the results after calibration